# Smart Search Using Face Recognition

Face detection and facial recognition along with recognized persons information fetched from database.

General Languages and versions

    •	Python version: 3.6
    •	Django version: 2.0.3
    •	OpenCV version: 3.4.0
    •	Mysql Database

Run -

    python manage.py runserver

Demo Video:

	https://www.youtube.com/watch?v=kSIoOlkR5Ow&feature=youtu.be

