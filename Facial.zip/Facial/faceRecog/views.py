from django.shortcuts import render, redirect
import cv2
import os
import numpy as np
import logging
from sklearn.model_selection import train_test_split
from . import dataset_fetch as df
from . import cascade as casc
from PIL import Image
import shutil

from time import time
from sklearn.decomposition import PCA
from sklearn.model_selection import GridSearchCV
from sklearn.svm import SVC
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
import pickle
import sqlite3
import random
from datetime import datetime 
import datetime
import tkinter as tk
from tkinter import simpledialog
from tkinter import messagebox
import requests

#from settings import BASE_DIR
# Create your views here.
def index(request):
    return render(request, 'index.html')
def errorImg(request):
    return render(request, 'error.html')


def create_dataset(request):
    #print request.POST
    userId = request.POST['userId']
    print (cv2.__version__)
    # Detect face
    #Creating a cascade image classifier
    faceDetect = cv2.CascadeClassifier('C:\\Users\\Goku\\Desktop\\Facial\\ml\\haarcascade_frontalface_default.xml')
    #camture images from the webcam and process and detect the face
    # takes video capture id, for webcam most of the time its 0.
    cam = cv2.VideoCapture(0)

    # Our identifier
    # We will put the id here and we will store the id with a face, so that later we can identify whose face it is
    id = userId
    # Our dataset naming counter
    sampleNum = 0
    # Capturing the faces one by one and detect the faces and showing it on the window
    while(True):
        # Capturing the image
        #cam.read will return the status variable and the captured colored image
        ret, img = cam.read()
        #the returned img is a colored image but for the classifier to work we need a greyscale image
        #to convert
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        #To store the faces
        #This will detect all the images in the current frame, and it will return the coordinates of the faces
        #Takes in image and some other parameter for accurate result
        faces = faceDetect.detectMultiScale(gray, 1.3, 5)
        #In above 'faces' variable there can be multiple faces so we have to get each and every face and draw a rectangle around it.
        for(x,y,w,h) in faces:
            # Whenever the program captures the face, we will write that is a folder
            # Before capturing the face, we need to tell the script whose face it is
            # For that we will need an identifier, here we call it id
            # So now we captured a face, we need to write it in a file
            sampleNum = sampleNum+1
            
            # Saving the image dataset, but only the face part, cropping the rest
            cv2.imwrite('C:\\Users\\Goku\\Desktop\\Facial\\ml\\dataset\\User.'+str(id)+'.'+str(sampleNum)+'.jpg', gray[y:y+h,x:x+w])
            # @params the initial point of the rectangle will be x,y and
            # @params end point will be x+width and y+height
            # @params along with color of the rectangle
            # @params thickness of the rectangle
            cv2.rectangle(img,(x,y),(x+w,y+h), (0,255,0), 2)
            # Before continuing to the next loop, I want to give it a little pause
            # waitKey of 100 millisecond
            cv2.waitKey(250)

        #Showing the image in another window
        #Creates a window with window name "Face" and with the image img
        cv2.imshow("Face",img)
        #Before closing it we need to give a wait command, otherwise the open cv wont work
        # @params with the millisecond of delay 1
        cv2.waitKey(1)
        #To get out of the loop
        if(sampleNum>50):
            break
    #releasing the cam
    cam.release()
    # destroying all the windows
    cv2.destroyAllWindows()
    source = os.listdir("./ml/dataset")
    destination = "./static/img"
    for files in source:
        if files.endswith(".51.jpg"):
            shutil.copy(os.path.join('./ml/dataset',files),destination)

    return redirect('/')

def trainer(request):
    '''
        In trainer.py we have to get all the samples from the dataset folder,
        for the trainer to recognize which id number is for which face.

        for that we need to extract all the relative path
        i.e. dataset/user.1.1.jpg, dataset/user.1.2.jpg, dataset/user.1.3.jpg
        for this python has a library called os
    '''
    import os
    from PIL import Image

    #Creating a recognizer to train
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    #Path of the samples
    path = os.path.abspath("ml\dataset")

    # To get all the images, we need corresponing id
    def getImagesWithID(path):
        # create a list for the path for all the images that is available in the folder
        # from the path(dataset folder) this is listing all the directories and it is fetching the directories from each and every pictures
        # And putting them in 'f' and join method is appending the f(file name) to the path with the '/'
        imagePaths = [os.path.join(path,f) for f in os.listdir(path)] #concatinate the path with the image name
        #print imagePaths

        # Now, we loop all the images and store that userid and the face with different image list
        faces = []
        Ids = []
        for imagePath in imagePaths:
            # First we have to open the image then we have to convert it into numpy array
            faceImg = Image.open(imagePath).convert('L') #convert it to grayscale
            # converting the PIL image to numpy array
            # @params takes image and convertion format
            faceNp = np.array(faceImg, 'uint8')
            # Now we need to get the user id, which we can get from the name of the picture
            # for this we have to slit the path() i.e dataset/user.1.7.jpg with path splitter and then get the second part only i.e. user.1.7.jpg
            # Then we split the second part with . splitter
            # Initially in string format so hance have to convert into int format
            ID = int(os.path.split(imagePath)[-1].split('.')[1]) # -1 so that it will count from backwards and slipt the second index of the '.' Hence id
            # Images
            faces.append(faceNp)
            # Label
            Ids.append(ID)
            #print ID
            cv2.imshow("training", faceNp)
            cv2.waitKey(10)
        return np.array(Ids), np.array(faces)

    # Fetching ids and faces
    ids, faces = getImagesWithID(path)

    #Training the recognizer
    # For that we need face samples and corresponding labels
    recognizer.train(faces, ids)

    # Save the recogzier state so that we can access it later
    recognizer.save('C:\\Users\\Goku\\Desktop\\Facial\\ml\\recognizer\\trainingData.yml')
    cv2.destroyAllWindows()

    return redirect('/')


def detect(request):
    faceDetect = cv2.CascadeClassifier('C:\\Users\\Goku\\Desktop\\Facial\\ml\\haarcascade_frontalface_default.xml')

    cam = cv2.VideoCapture(0)
    # creating recognizer
    rec = cv2.face.LBPHFaceRecognizer_create();
    # loading the training data
    rec.read('C:\\Users\\Goku\\Desktop\\Facial\\ml\\recognizer\\trainingData.yml')
    getId = 0
    font = cv2.FONT_HERSHEY_SIMPLEX
    userId = 0
    while(True):
        ret, img = cam.read()
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        faces = faceDetect.detectMultiScale(gray, 1.3, 5)
        for(x,y,w,h) in faces:
            cv2.rectangle(img,(x,y),(x+w,y+h), (0,255,0), 2)

            getId,conf = rec.predict(gray[y:y+h, x:x+w]) #This will predict the id of the face

            #print conf;
            if conf<50:
                userId = getId
                cv2.putText(img, "Detected",(x,y+h), font, 2, (0,255,0),2)
            else:
                cv2.putText(img, "Unknown",(x,y+h), font, 2, (0,0,255),2)

            # Printing that number below the face
            # @Prams cam image, id, location,font style, color, stroke

        cv2.imshow("Face",img)
        if(cv2.waitKey(1) == ord('q')):
            break

        elif(userId != 0):
            cv2.waitKey(1000)
            cam.release()
            cv2.destroyAllWindows()
            return redirect('/records/details/'+str(userId))
        else:
            con = sqlite3.connect('db.sqlite3')
            print('Done')
            print("\n")
            cursor = con.cursor()

            #Enter Mobile Number
            ROOT = tk.Tk()

            ROOT.withdraw()
            cam.release()
            cv2.destroyAllWindows()
            # the input dialog
            USER_INP = simpledialog.askstring(title="OTP Login",
                                            prompt="Enter Your Regester Mobile Number :")
            Mobno = int(USER_INP)
            print(Mobno)
            print("\n")
            

            sql_select_Query = "SELECT id,Phone FROM records_records WHERE Phone= ?;"
            data = (Mobno)
            cursor.execute(sql_select_Query,(data,))
            records = cursor.fetchall()
            if len(records)==0:
                print('You are not register User')
                messagebox.showinfo("Error","You are not register User")
                cam.release()
                cv2.destroyAllWindows()
                return redirect('/')
            else:
                a = records[0]
                print("\n")
                print(a)
                u_id = a[0]
                u_mnum = a[1]
                print(u_id,u_mnum)
                print("\n")
                print("Record Retrive successfully ")
                messagebox.showinfo("Information","OTP is send to register Mobile Number kindly Enter within 10min")
            #Generate Random 4 digit Number
            otp = random.randint(1000,9999)
            print(otp)
            #Date time
            now = datetime.datetime.now()
            print(now)
            plus_ten = now + datetime.timedelta(minutes = 10)
            print(plus_ten)
            sql_otp_Query = "SELECT * from records_otp where id= ?;"
            data = (u_id)
            cursor.execute(sql_otp_Query,(data,))
            records = cursor.fetchall()
            print(records)
            print(len(records))
            if len(records)==0:
                sql_otp_Query = "INSERT INTO records_otp (id, Mobile_Number, otp, Start_time_stamp, End_time_stamp) VALUES (?,?,?,?,?);"
                data_tuple = (u_id,u_mnum,otp,now,plus_ten)
                cursor.execute(sql_otp_Query, data_tuple)
                con.commit()
                print("OTP inserted successfully into records_otp table")
            else:
                sql_update_query = "UPDATE records_otp SET otp = ?,Start_time_stamp = ?,End_time_stamp = ? WHERE id = ?;"
                data = (otp,now,plus_ten, u_id)
                cursor.execute(sql_update_query, data)
                con.commit()
                print("OTP Updated successfully into records_otp table")
                sql_otp_Query = "SELECT * from records_otp where id= ?;"
                data = (u_id)
                cursor.execute(sql_otp_Query,(data,))
                records = cursor.fetchall()
                a = records[0]
                print("\n")
                print(a)
                u_id = a[0]
                u_mnum = a[1]
                otp_ver = a[2]
                end_time = a[4]
                otp_end_time = datetime.datetime.strptime(end_time,'%Y-%m-%d %H:%M:%S.%f')
                #res = datetime.strptime(now1,'%d-%m-%y %I:%M:%S.%f') 
                
                print(u_id,u_mnum,otp_ver,otp_end_time)
                sendurl = "http://103.16.101.52:8080/sendsms/bulksms?username=ams1-allios&password=allios&type=0&dlr=1&destination="+str(u_mnum)+"&source=ALLIOS&message=OTP for Login is :- "+str(otp_ver)
                requests.get(sendurl)
                print('Done')
                USER_INP = simpledialog.askstring(title="OTP Login",prompt="Enter Your OTP :")
                EntOTP = int(USER_INP)
                now = datetime.datetime.now()
                print(now)
                print(otp_end_time)
                print(EntOTP)
                print("\n")
                ROOT.destroy()
                if(EntOTP == otp_ver and now < otp_end_time):
                    print("OTP is Valid")
                    cursor.close()
                    cam.release()
                    cv2.destroyAllWindows()
                    return redirect('/records/details/'+str(u_id))
                else:
                    messagebox.showinfo("Error","OTP IS NOT VALID")
                    cam.release()
                    cv2.destroyAllWindows()
                    return redirect('/')

    cam.release()
    cv2.destroyAllWindows()
    return redirect('/')

def eigenTrain(request):
    path = BASE_DIR+'/ml/dataset'

    # Fetching training and testing dataset along with their image resolution(h,w)
    ids, faces, h, w= df.getImagesWithID(path)
    print ('features'+str(faces.shape[1]))
    # Spliting training and testing dataset
    X_train, X_test, y_train, y_test = train_test_split(faces, ids, test_size=0.25, random_state=42)
    #print ">>>>>>>>>>>>>>> "+str(y_test.size)
    n_classes = y_test.size
    target_names = ['Manjil Tamang', 'Marina Tamang','Anmol Chalise']
    n_components = 15
    print("Extracting the top %d eigenfaces from %d faces"
          % (n_components, X_train.shape[0]))
    t0 = time()

    pca = PCA(n_components=n_components, svd_solver='randomized',whiten=True).fit(X_train)

    print("done in %0.3fs" % (time() - t0))
    eigenfaces = pca.components_.reshape((n_components, h, w))
    print("Projecting the input data on the eigenfaces orthonormal basis")
    t0 = time()
    X_train_pca = pca.transform(X_train)
    X_test_pca = pca.transform(X_test)
    print("done in %0.3fs" % (time() - t0))

    # #############################################################################
    # Train a SVM classification model

    print("Fitting the classifier to the training set")
    t0 = time()
    param_grid = {'C': [1e3, 5e3, 1e4, 5e4, 1e5],
                  'gamma': [0.0001, 0.0005, 0.001, 0.005, 0.01, 0.1], }
    clf = GridSearchCV(SVC(kernel='rbf', class_weight='balanced'), param_grid)
    clf = clf.fit(X_train_pca, y_train)
    print("done in %0.3fs" % (time() - t0))
    print("Best estimator found by grid search:")
    print(clf.best_estimator_)

    # #############################################################################
    # Quantitative evaluation of the model quality on the test set

    print("Predicting people's names on the test set")
    t0 = time()
    y_pred = clf.predict(X_test_pca)
    print("Predicted labels: ",y_pred)
    print("done in %0.3fs" % (time() - t0))

    print(classification_report(y_test, y_pred, target_names=target_names))
    # print(confusion_matrix(y_test, y_pred, labels=range(n_classes)))

    # #############################################################################
    # Qualitative evaluation of the predictions using matplotlib

    def plot_gallery(images, titles, h, w, n_row=3, n_col=4):
        """Helper function to plot a gallery of portraits"""
        plt.figure(figsize=(1.8 * n_col, 2.4 * n_row))
        plt.subplots_adjust(bottom=0, left=.01, right=.99, top=.90, hspace=.35)
        for i in range(n_row * n_col):
            plt.subplot(n_row, n_col, i + 1)
            plt.imshow(images[i].reshape((h, w)), cmap=plt.cm.gray)
            plt.title(titles[i], size=12)
            plt.xticks(())
            plt.yticks(())

    # plot the gallery of the most significative eigenfaces
    eigenface_titles = ["eigenface %d" % i for i in range(eigenfaces.shape[0])]
    plot_gallery(eigenfaces, eigenface_titles, h, w)
    # plt.show()

    '''
        -- Saving classifier state with pickle
    '''
    svm_pkl_filename = BASE_DIR+'/ml/serializer/svm_classifier.pkl'
    # Open the file to save as pkl file
    svm_model_pkl = open(svm_pkl_filename, 'wb')
    pickle.dump(clf, svm_model_pkl)
    # Close the pickle instances
    svm_model_pkl.close()



    pca_pkl_filename = BASE_DIR+'/ml/serializer/pca_state.pkl'
    # Open the file to save as pkl file
    pca_pkl = open(pca_pkl_filename, 'wb')
    pickle.dump(pca, pca_pkl)
    # Close the pickle instances
    pca_pkl.close()

    plt.show()

    return redirect('/')


def detectImage(request):
    userImage = request.FILES['userImage']

    svm_pkl_filename =  BASE_DIR+'/ml/serializer/svm_classifier.pkl'

    svm_model_pkl = open(svm_pkl_filename, 'rb')
    svm_model = pickle.load(svm_model_pkl)
    #print "Loaded SVM model :: ", svm_model

    pca_pkl_filename =  BASE_DIR+'/ml/serializer/pca_state.pkl'

    pca_model_pkl = open(pca_pkl_filename, 'rb')
    pca = pickle.load(pca_model_pkl)
    #print pca

    '''
    First Save image as cv2.imread only accepts path
    '''
    im = Image.open(userImage)
    #im.show()
    imgPath = BASE_DIR+'/ml/uploadedImages/'+str(userImage)
    im.save(imgPath, 'JPEG')

    '''
    Input Image
    '''
    try:
        inputImg = casc.facecrop(imgPath)
        inputImg.show()
    except :
        print("No face detected, or image not recognized")
        return redirect('/error_image')

    imgNp = np.array(inputImg, 'uint8')
    #Converting 2D array into 1D
    imgFlatten = imgNp.flatten()
    #print imgFlatten
    #print imgNp
    imgArrTwoD = []
    imgArrTwoD.append(imgFlatten)
    # Applyting pca
    img_pca = pca.transform(imgArrTwoD)
    #print img_pca

    pred = svm_model.predict(img_pca)
    print(svm_model.best_estimator_)
    print (pred[0])

    return redirect('/records/details/'+str(pred[0]))
