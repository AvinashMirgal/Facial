/* particlesJS.load(@dom-id, @path-json, @callback (optional)); */
particlesJS.load('particles-js', 'static/particles.json', function() {
  //console.log('callback - particles.js config loaded');
});


onload=function(){
  var e=document.getElementById("refreshed");
  if(e.value=="no")e.value="yes";
  else{e.value="no";location.reload();e.value="no";}
  }
  
  $("#querystring").click(function(){
    window.location.href = window.location.href.split('?')[0];
});