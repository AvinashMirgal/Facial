# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from .models import Records
from django.shortcuts import render
from django.http import HttpResponse
import sqlite3

# Create your views here.
def index(request):
    records = Records.objects.all()[:10]    #getting the first 10 records
    context = {
        'records': records
    }
    return render(request, 'records.html', context)

def details(request, id):
    record = Records.objects.get(id=id)    
    context = {
        'record' : record
    }
    return render(request, 'details.html', context)

def BillPay(request,id):
    try:
        con = sqlite3.connect('db.sqlite3')
        print('Done')
        cursor = con.cursor()

        sql_select_Query = "SELECT * FROM records_records;"

        cursor.execute(sql_select_Query)
        records = cursor.fetchall()
        a = records[0]
        num1 = a[11]
        num2 = int(request.GET['bill_amount'])
        res = num1 - num2
        print(res)



        sql_update_query = "UPDATE records_records SET Amount = ? WHERE id = ?;"
        data = (res, id)
        cursor.execute(sql_update_query, data)
        con.commit()
        print("Record Updated successfully ")
        cursor.close()

    except sqlite3.Error as error:
        print("Failed to update sqlite table", error)
    finally:
        if (con):
            con.close()
            print("The SQLite connection is closed")
    
    record = Records.objects.get(id=id)    
    context = {
        'record' : record,
        'Result' : res
    }
    return render(request,"bill_payment.html",context)

