# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from datetime import datetime
from django.db import models

# Create your models here.
class Records(models.Model):
    id = models.CharField(max_length=100, primary_key=True)
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50, null=True)
    email = models.CharField(max_length=150, null=True)
    Phone = models.CharField(max_length=50, null=True)
    Pan_Card = models.CharField(max_length=50, null=True)
    Aadhar_card = models.CharField(max_length=150, null=True)
    Debit_card_Num = models.CharField(max_length=150, null=True)
    Name_On_Debit_Card = models.CharField(max_length=50, null=True)
    credit_card_Num = models.CharField(max_length=150, null=True)
    Name_On_Credit_Card = models.CharField(max_length=50, null=True)
    Amount = models.CharField(max_length=50, null=True)
    #bio = models.TextField()
    recorded_at = models.DateTimeField(default=datetime.now, blank=True)

    def __str__(self):
        return self.first_name
    class Meta:
        verbose_name_plural = "Records"
